from . import kpi_dashboard_menu
