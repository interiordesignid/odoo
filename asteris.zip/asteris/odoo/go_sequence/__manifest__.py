{
    'name' : 'Odoo Sequence Utility',
    'version' : '1.0',
    "author" : "William Wino",
    'summary': 'A Sequence Utility',
    'sequence': 1,
    'description': """
    """,
    'category': '',
    'website': 'https://exoze.com',
    'images' : [],
    'depends' : [],
    'data': [
    ],
    'demo': [
    ],
    'qweb': [
        
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'post_init_hook': False,
}
