from. import res_partner
from. import ms_poli
from. import ms_pendaftaran
from. import ms_pemeriksaan